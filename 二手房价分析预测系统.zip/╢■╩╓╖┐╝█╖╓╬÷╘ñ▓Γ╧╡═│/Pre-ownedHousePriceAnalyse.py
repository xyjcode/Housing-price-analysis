import pandas  # 导入数据统计模块
import matplotlib  # 导入图表模块
import matplotlib.pyplot as plt # 导入绘图模块
from sklearn.svm import LinearSVR  # 导入回归函数
# 避免中文乱码
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False
# 1. 读取数据
data = pandas.read_csv('data.csv')  # 读取csv数据文件
#print(data.shape)
del data['Unnamed: 0']  # 将索引列删除,del python的内置函数
print(data.head())
# 2. 数据清洗
# 2.1 空值处理
print(data[data.isnull()]) # 查看是否有空值
# 删除data数据中的所有空值
data.dropna(axis=0, how='any', inplace=True)
#print(data.shape)
# 2.2 重复值处理
# 查看是否有重复值
print(data[data.duplicated()])
# print(data[data['小区名字']=='五环高尔夫家园'])
# 删除data数据中的重复值
data.drop_duplicates(inplace=True)
print(data.shape)
# 2.3 数据变换
# 去掉总价，单价，'建筑面积'的单位
data['总价'] = data['总价'].replace('万', '',regex=True).astype(float)
#print(data['总价'])
data['单价'] = data['单价'].replace('元/平米', '',regex=True).astype(float)
#print(data['单价'])
data['建筑面积'] = data['建筑面积'].replace('平米', '',regex=True).astype(float)
print(data['建筑面积'])

# 3.数据分析及可视化
# 3.1 各区域的二手房均价
# 3.1.1 数据按各区域进行划分，然后计算每个区域的二手房均价
group = data.groupby('区域')  # 将房子区域分组
average_price_group = group['单价'].mean()  # 计算每个区域的均价
#print('各区域的房子均价:',average_price_group)
region = average_price_group.index  # 区域
average_price = average_price_group.values.astype(int) # 区域对应的均价
#print(average_price)
# 3.1.2 将区域及对应的均价信息通过纵向条形统计图显示
x = region
y = average_price
title = '各区二手房均价分析'
plt.figure()                          # 图形画布
plt.bar(x,y, alpha=0.8)               # 绘制条形图
plt.xlabel('区域')                    # 区域文字
plt.ylabel('均价')                    # 均价文字
plt.title(title)                      # 表标题文字
# 为每一个图形加数值标签
for x, y in enumerate(y):
    plt.text(x, y + 100, y, ha='center')
plt.show()                            # 显示图表

# 3.2 各区二手房数量所占比例
# 将数据按区域进行分组并获取每个区域的房子数量，
# 最后计算每个区域的房子数量占全部区域房子总数的百分比
group_number = data.groupby('区域').size()  # 房子区域分组数量
print('各区域的房子数量:',group_number)
region = group_number.index  # 区域
numbers = group_number.values  # 获取每个区域内房子出售的数量
percentage = numbers / numbers.sum() * 100  # 计算每个区域房子数量的百分比
# 3.2.2 将区域二手房数量所占比例通过饼图显示
size = percentage
label = region
title = '各区二手房数量所占比例分析'
plt.pie(size, labels=label,labeldistance=1.05,
            autopct="%1.1f%%", shadow=True,
            startangle=0, pctdistance=0.6)
plt.axis('equal')  # 设置横轴和纵轴大小相等，这样饼才是圆的
plt.title(title, fontsize=12)
plt.legend(bbox_to_anchor=(0.03, 1)) #设置图例显示位置
plt.show()    # 显示饼图

# 3.3 全市二手房装修类型分析
# 3.3.1 按二手房的装修类型进行分组，并统计每个分组的数量
# 分别获取装修类型，和装修类型对应的数量
group_renovation = data.groupby('装修').size() #将房子装修程度分组并统计数量
type = group_renovation.index  # 装修程度
number = group_renovation.values  # 装修程度对应的数量
# 3.3.2  将全市二手房装修类型通过纵向条形统计图显示
x = type
y = number
title = '各区二手房装修类型分析'
plt.bar(x,y, alpha=0.8)  # 绘制条形图
plt.xlabel("装修类型") # 区域文字
plt.ylabel("数量") # 均价文字
plt.title(title) # 表标题文字
# 为每一个图形加数值标签
for x, y in enumerate(y):
    plt.text(x, y + 10, y, ha='center')
plt.show()

# 3.4 热门户型均价分析
# 3.4.1 首先计算热门户型：
# 1）对户型进行分组并获取每个分组所对应的数量
# 2）按各户型数量降序排列，获取前5个户型作为热门户型
# 3）计算热门户型的均值
house_type_number = data.groupby('户型').size()  # 房子户型分组数量
sort_values = house_type_number.sort_values(ascending=False)  # 将户型分组数量进行降序
top_five = sort_values.head(5)  # 提取前5组户型数据
house_type_mean = data.groupby('户型')['单价'].mean()  # 计算每个户型的均价
type = house_type_mean[top_five.index].index           # 户型
price = house_type_mean[top_five.index].values.astype(int) # 户型对应的均价
# 3.4.2 将热门户型的数量用水平条形图显示
# x=type
# y=price
title = '热门户型均价分析'
plt.barh(type, price, height=0.3,
         color='r', alpha=0.8)  #从下往上画水平条形图
plt.xlim(0, 15000)      # X轴的均价0~15000
plt.xlabel("均价")
plt.title(title)
# 为每一个图形加数值标签
for y, x in enumerate(price):
    plt.text(x + 10, y,str(x) + '元', va='center')
plt.show()

# 3.5 二手房售价预测
# 需要提供二手房源数据中的参考数据（特征值），
# 这里将“户型”与“建筑面积”作为参考数据来进行房价的预测，
# 所以需要观察“户型”数据是否符合分析条件
data_copy = data.copy()      # 拷贝数据
print(data_copy[['户型', '建筑面积']].head())
data_copy[['室', '厅', '卫']] = data_copy['户型'].str.extract('(\d+)室(\d+)厅(\d+)卫')
print(data_copy[['室', '厅', '卫']])
data_copy['室'] = data_copy['室'].astype(float)  # 将房子室转换为浮点类型
data_copy['厅'] = data_copy['厅'].astype(float)  # 将房子厅转换为浮点类型
data_copy['卫'] = data_copy['卫'].astype(float)  # 将房子卫转换为浮点类型
print(data_copy[['室', '厅', '卫']].head())  # 打印“室”、“厅”、“卫”数据
# 删除其他列
del data_copy['小区名字']
del data_copy['户型']
del data_copy['朝向']
del data_copy['楼层']
del data_copy['装修']
del data_copy['区域']
del data_copy['单价']
data_copy.dropna(axis=0, how='any', inplace=True)  # 删除data数据中的所有空值
# 获取“建筑面积”小于300平米的房子信息
new_data = data_copy[data_copy['建筑面积'] < 300].reset_index(drop=True)
print(new_data.head())  # 打印处理后的头部信息
print(new_data.shape)
#  添加自定义预测数据
new_data.loc[2392] = [None, 88.0, 2.0, 1.0, 1.0]
new_data.loc[2393] = [None, 136.0, 3.0, 2.0, 2.0]
data_train = new_data.loc[0:2391]
x_list = ['建筑面积', '室', '厅', '卫']  # 自变量参考列
data_mean = data_train.mean()  # 获取平均值
data_std = data_train.std()  # 获取标准偏差
data_train = (data_train - data_mean) / data_std  # 数据标准化
print(data_train)
x_train = data_train[x_list].values  # 特征数据
y_train = data_train['总价'].values  # 目标数据，总价
linearsvr = LinearSVR(C=0.1)  # 创建LinearSVR()对象
linearsvr.fit(x_train, y_train)  # 训练模型
x = ((new_data[x_list] - data_mean[x_list]) / data_std[x_list]).values  # 标准化特征数据
new_data['y_pred'] = linearsvr.predict(x) * data_std['总价'] + data_mean['总价']  # 添加预测房价的信息列
print('真实值与预测值分别为：\n', new_data[['总价', 'y_pred']])
new_data.to_csv('t.csv')
y = new_data.loc[2380:,['总价']] # 获取2380以后的真实总价[2380:]
y_pred = new_data[['y_pred']][2380:]  # 获取2380以后的预测总价
print(y)
print(y_pred)
# 3.5.2 显示预测房价折线图
title = '二手房售价预测'
# 绘制折线，并在折点添加蓝色圆点
plt.plot(y, color='r', marker='o',label='真实房价')
plt.plot(y_pred, color='b', marker='*', label='预测房价')
plt.xlabel('房子数量')
plt.ylabel('房子总价')
plt.title(title)  # 表标题文字
plt.legend()  # 显示图例
plt.grid()  # 显示网格
plt.show()  # 显示图表
